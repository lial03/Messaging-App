package com.example.ChatApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
